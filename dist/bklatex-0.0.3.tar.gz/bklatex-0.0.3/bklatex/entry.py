class entry:
    def __init__(self, date, debit_accounts, credit_accounts, debit_amounts, credit_amounts, debit_folios, credit_folios, narration):
        self.date = date
        self.debit_accounts = debit_accounts
        self.credit_accounts = credit_accounts
        self.debit_amounts = debit_amounts
        self.credit_amounts = credit_amounts
        self.debit_folios = debit_folios
        self.credit_folios = credit_folios
        self.narration = narration
